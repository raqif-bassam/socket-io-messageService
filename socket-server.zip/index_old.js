const app = require('express')();
const http = require('http').createServer(app);
const io = require('socket.io')(http, {
  cors: {
    cors: {
    origin: "http://dellshare.bd",
    methods: ["GET", "POST"]
  }
  }
});


io.on('connection', (socket) => {
  console.log('a user connected');
  socket.on('disconnect', () => {
    console.log('user disconnected');
  });
  socket.on('test event', function(msg)
{
    socket.broadcast.emit('test event',msg.d);    
});
  socket.emit('test event', 'message from socket server ');
});
http.listen(3000, () => {
  console.log('listening on *:3000');
});