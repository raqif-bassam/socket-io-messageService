const app = require('express')();
const fs = require('fs');

var options = {
    key: fs.readFileSync('C:/cert/star_brandshare_net_02.key.pem'),
    cert: fs.readFileSync('C:/cert/star_brandshare_net_02.pem'),
    passphrase: 'dhgubaba'
};
const cors = require('cors');
const whitelist = ['http://localhost:5000', 'http://abu.dellshare.bassam','http://dellshare.bassam', 'http://abu.dellshare.bd','http://mainline.dellshare.com'];
const corsOptions = {
  credentials: true, // This is important.
  origin: (origin, callback) => {
    if(whitelist.includes(origin))
      return callback(null, true)

      callback(new Error('Not allowed by CORS'));
  }
}
app.get('/', (req, res) => {
  res.send('<h1>Hey Socket.io</h1>');
});


const http = require('https').createServer(options,app);
const io = require('socket.io')(http, {
  cors: corsOptions
});

const port = process.env.PORT || 5000;

io.on('connection', (socket) => {
    console.log('user connected');
	console.log('Socket Protocol: ' +socket.conn.protocol);
	socket.on('disconnect', () => {
		console.log('user disconnected');
	});
	socket.on('test', function(msg)
	{
		console.log(msg);
		socket.broadcast.emit('testB',msg.d);    
	});
	
	socket.on('BrandShare', function(msg)
	{
		console.log(msg);
		socket.broadcast.emit(msg.portal,msg.d);  
	});
    
	socket.on('BrandShareInstantMessage', function(msg)
	{
		console.log(msg);
		socket.broadcast.emit(msg.portal+'_InstantPopUp',msg.d);    
	});

	socket.on('BrandShareTemplateVersionRCB', function(msg)
	{
		console.log(msg);
		socket.broadcast.emit(msg.portal+'_TemplateVersionRCB',msg.d);   
	});
    
	socket.on('BrandShareActivityVersionRCB', function(msg)
	{ 
		console.log(msg);
		socket.broadcast.emit(msg.portal+'_ActivityVersionRCB',msg.d);   
	});
	
	socket.on('BrandShareActivityVersionHTA', function(msg)
	{
		console.log(msg);
		socket.broadcast.emit(msg.portal+'_ActivityVersionHTA',msg.d);      
	});
	
	socket.on('OutputGenerationCompletionData', function(msg)
	{
		console.log(msg);
		socket.broadcast.emit(msg.portal+'_OutputGenerationCompletionData', msg.d);
	});

	socket.on('UrnIngestionCompleted', function(msg)
	{
		console.log(msg);
		socket.broadcast.emit(msg.portal+'_UrnIngestionCompleted', msg.d);
	});
	
	socket.on('ProofCreationStatusReceived', function(msg)
	{
		console.log(msg);
		socket.broadcast.emit(msg.portal+'_ProofCreationStatusReceived', msg.d);
	});
	
	socket.on('EndPointStatusReceived', function(msg)
	{
		console.log(msg);
		socket.broadcast.emit(msg.portal+'_EndPointStatusReceived', msg.d);
	});
	
	socket.emit('test', 'message from socket server ');
});

http.listen(port, () => {
    console.log(`started on port: ${port}`);
});