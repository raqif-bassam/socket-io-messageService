var Service = require('node-windows').Service;


var svc = new Service({
  name:'SockerServer',
  description: 'The nodejs.org example web server.',
  script: 'C:\\socket-server\\index.js'
});


svc.on('install',function(){
  svc.start();
});

svc.install();